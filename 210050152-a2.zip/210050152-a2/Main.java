import syntaxtree.*;
import visitor.*;

import java.io.*;
import java.util.*;

public class Main {
   public static void main(String[] args) {
      try {
         PrintStream console = System.out;
         FileOutputStream fileOutputStream = new FileOutputStream("output.txt");
         PrintStream filePrintStream = new PrintStream(fileOutputStream);
         System.setOut(filePrintStream);
         Node root = new a2java(System.in).Goal();
         CFGGen cfgGen = new CFGGen();
         root.accept(cfgGen);
         ProgramCFG programCFG = cfgGen.getCFG();
         // System.out.println("travelnithya1 done!!!!!!");

         root.accept(new travelnithya2());

         root.accept(new travelnithya1());

         // System.out.println("travelnithya1 done!!!!!!");
         
         // Printing the DOT file
         // BB.printBBDOT(programCFG);
         
         // For iterating over the program
         for (String className : programCFG.classMethodList.keySet()) {
            Set<String> methodList = programCFG.classMethodList.get(className);
            // System.out.println("Class: " + className);
            for (String methodName : methodList) {
               // System.out.println("Method: " + methodName);
               BB currentMethodBB = programCFG.methodBBSet.get(methodName);
               // BB.printBB(currentMethodBB);
               List<String>dummy=new ArrayList<>();
               // // collect info
               // BB.nodetravelorder(currentMethodBB, methodName);

               // // initialise
               // BB.initialise(dummy, currentMethodBB, methodName);
               // BB.proceed(currentMethodBB, methodName);
               // System.out.println("///////////////////////////////////");

            }
        }

         myvisit1 mv1 = new myvisit1();
         root.accept(mv1);
               // System.out.println("///////////////////////////////////");

         System.setOut(console);
         filePrintStream.close();

         
         BufferedReader bufferedReader2 = new BufferedReader(new FileReader("output.txt"));

         a2java.ReInit(bufferedReader2);

         Node root2 = a2java.Goal();  
         bufferedReader2.close();

         CFGGen cfgGen2 = new CFGGen();
         root2.accept(cfgGen2);
         ProgramCFG programCFG2 = cfgGen2.getCFG();
         root.accept(new travelnithya3());

         root.accept(new travelnithya4());
         // System.out.println("hurray 2");

         // ✅ Process the second CFG
         for (String className2 : programCFG2.classMethodList.keySet()) {
            Set<String> processedMethodList2 = programCFG2.classMethodList.get(className2);
            // System.out.println("Class: " + className2);
            for (String methodName2 : processedMethodList2) {
               // System.out.println("Method: " + methodName2);
               BB processedMethodBB2 = programCFG2.methodBBSet.get(methodName2);
               // BB.printBB(processedMethodBB2);
                 BB.nodetravelorder(processedMethodBB2, methodName2);
               List<String>dummy=new ArrayList<>();

               // initialise
               BB.initialise(dummy, processedMethodBB2, methodName2);
               BB.proceed(processedMethodBB2, methodName2);
            }
         }
         myvisit2 mv2 = new myvisit2();
         root2.accept(mv2);


      } catch (ParseException e) {
         System.out.println("Parse Error: " + e.toString());
      } catch (IOException e) {
         System.out.println("File Error: " + e.getMessage());
      }
   }
}