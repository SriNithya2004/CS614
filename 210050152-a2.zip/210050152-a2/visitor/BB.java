package visitor;

import syntaxtree.*;

import java.io.FileWriter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// A basic block contains a list of instructions
// and a list of incoming/outgoing edges to BB's

public class BB {
    public ArrayList<Instruction> instructions;
    public Set<BB> incomingEdges, outgoingEdges;
    static int id = 0;
    public String name;

    public BB() {
        instructions = new ArrayList<>();
        incomingEdges = new HashSet<>();
        outgoingEdges = new HashSet<>();
        name = "bb" + (id++);
        // Add a dummy instruction to start of every block
        instructions.add(new Instruction(null));
    }

    public void pushInstruction(Instruction i) {
        instructions.add(i);
    }
   public boolean containsInstruction(Instruction i) {
        return instructions.contains(i); // Ensure `instructions` is a List or Set
    }
    public BB getNextBB() {
        if (!outgoingEdges.isEmpty()) {
            return outgoingEdges.iterator().next(); // Get the next BB from edges
        }
        return null; // If no outgoing edges, return null
    }
    public void addIncomingEdge(BB incomingEdge) {
        incomingEdges.add(incomingEdge);
    }

    public void addOutgoingEdge(BB outgoingEdge) {
        outgoingEdges.add(outgoingEdge);
    }

    Set<String> getInSet() {
        return instructions.get(0).getInSet();
    }

    Set<String> getOutSet() {
        return instructions.get(instructions.size() - 1).getOutSet();
    }

    public static void printBB(BB startNode) {
        Set<BB> visitedBBs = new HashSet<>();
        Stack<BB> worklist = new Stack<>();

        worklist.push(startNode);

        while (worklist.size() > 0) {
            BB currentBB = worklist.pop();
            visitedBBs.add(currentBB);

            System.out.print(currentBB.name + " : [PRED] [");

            for (BB bbIncoming : currentBB.incomingEdges) {
                System.out.print(bbIncoming.name + " ");
            }

            System.out.println("]");
            

            StringBuilder sb = new StringBuilder();

            for (Instruction i : currentBB.instructions) {
                if (i.instructionNode != null) {
                    Node instruction = i.instructionNode;
                    if (instruction instanceof VarDeclaration) {
                        VarDeclaration curr = (VarDeclaration) instruction;
                        sb.append(getTypeString(curr.f0) + " " + curr.f1.f0.tokenImage + ";\n");
                    } else if (instruction instanceof AssignmentStatement) {
                        AssignmentStatement curr = (AssignmentStatement) instruction;
                        String lSide = curr.f0.f0.tokenImage;
                        String rSide = getExpressionString(curr.f2);
                        sb.append(lSide + " = " + rSide + ";\n");
                    } else if (instruction instanceof MethodDeclaration) {
                        MethodDeclaration node = (MethodDeclaration) i.instructionNode;
                        sb.append("return " + node.f10.f0.tokenImage + ";\n");
                    } else if (instruction instanceof PrintStatement) {
                        PrintStatement node = (PrintStatement) i.instructionNode;
                        sb.append("System.out.println(" + node.f2.f0.tokenImage + ");\n");
                    } else if(i.instructionNode instanceof ArrayAssignmentStatement) {
                        ArrayAssignmentStatement node = (ArrayAssignmentStatement) i.instructionNode;
                        String lSide = node.f0.f0.tokenImage + "_" + node.f2.f0.tokenImage;
                        String offset = node.f2.f0.tokenImage;
                        String rSide = node.f5.f0.tokenImage;
                        sb.append(lSide + "[" + offset + "] = " + rSide + ";\n");
                    } else if(i.instructionNode instanceof FieldAssignmentStatement) {
                        FieldAssignmentStatement node = (FieldAssignmentStatement) i.instructionNode;
                        String lSide = node.f0.f0.tokenImage;
                        String field = node.f2.f0.tokenImage;
                        String rSide = node.f4.f0.tokenImage;
                        sb.append(lSide + "." + field + " = " + rSide + ";\n");
                    } else if (i.instructionNode instanceof IfthenStatement) {
                        sb.append(((IfthenStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else if (i.instructionNode instanceof IfthenElseStatement) {
                        sb.append(((IfthenElseStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else if (i.instructionNode instanceof WhileStatement) {
                        sb.append(((WhileStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else {
                        throw new Error("Unhandled instruction in Basic Block: " + i.instructionNode);
                    }

                }
            }
            System.out.print(sb.toString());
            // for (Instruction i : currentBB.instructions) {
            //     if (i.instructionNode == null) {
            //         // System.out.println("Dummy Inst");
            //     } else {
            //         System.out.println(i.instructionNode.toString());
            //     }
            // }
            for (BB bbs : currentBB.outgoingEdges) {
                if (!visitedBBs.contains(bbs)) {
                    if (!worklist.contains(bbs)) {
                        worklist.push(bbs);
                    }
                }
            }
            System.out.print("[SUCC] [");
            for (BB bbIncoming : currentBB.outgoingEdges) {
                System.out.print(bbIncoming.name + " ");
            }
            System.out.println("]\n");

        }
    }

    public static String getExpressionString(Expression node) {
        switch (node.f0.which) {
            case 0: {
                OrExpression curr = (OrExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                return  lBinop + " || " + rBinop;
            }
            case 1: {
                AndExpression curr = (AndExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                return  lBinop + " && " + rBinop;
            }
            case 2: {
                CompareExpression curr = (CompareExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                return  lBinop + " <= " + rBinop;
            }
            case 3: {
                neqExpression curr = (neqExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                theusevariables.add(lBinop);
                theusevariables.add(rBinop);
                return  lBinop + " != " + rBinop;
            }
            case 4: {
                PlusExpression curr = (PlusExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                theusevariables.add(lBinop);
                theusevariables.add(rBinop);
                return  lBinop + " + " + rBinop;
            }
            case 5: {
                MinusExpression curr = (MinusExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                 theusevariables.add(lBinop);
                theusevariables.add(rBinop);
                return  lBinop + " - " + rBinop;
            }
            case 6: {
                TimesExpression curr = (TimesExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                theusevariables.add(lBinop);
                theusevariables.add(rBinop);
                return  lBinop + " * " + rBinop;
            }
            case 7: {
                DivExpression curr = (DivExpression) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                theusevariables.add(lBinop);
                theusevariables.add(rBinop);
                return  lBinop + " / " + rBinop;
            }
            case 8: {
                ArrayLookup curr = (ArrayLookup) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                String rBinop = curr.f2.f0.tokenImage;
                theusevariables.add(rBinop);
                return  lBinop + "[" + rBinop + "]";
            }
            case 9: {
                ArrayLength curr = (ArrayLength) node.f0.choice;
                String lBinop = curr.f0.f0.tokenImage;
                return  lBinop + ".length";
            }
            case 10: {
                MessageSend curr = (MessageSend) node.f0.choice;
                String obj = curr.f0.f0.tokenImage;
                String method = curr.f2.f0.tokenImage;
                StringBuilder sb = new StringBuilder();

                sb.append(obj + "." + method+"( ");

                if (curr.f4.present()) {
                    ArgList n = (ArgList) curr.f4.node;
                    sb.append(n.f0.f0.tokenImage + " ");
                    theusevariables.add(n.f0.f0.tokenImage);
                
                    for (Enumeration<Node> e = n.f1.elements(); e.hasMoreElements(); ) {
                        ArgRest r = (ArgRest) e.nextElement();
                        sb.append(r.f1.f0.tokenImage + " ");
                        theusevariables.add(r.f1.f0.tokenImage);

                    }
                }
                sb.append(")");
                return sb.toString();
            }
            case 11: {
                PrimaryExpression curr = (PrimaryExpression) node.f0.choice;
                switch (curr.f0.which) {
                    case 0:
                        return ((IntegerLiteral) curr.f0.choice).f0.tokenImage;
                    case 1:
                        return ((TrueLiteral) curr.f0.choice).f0.tokenImage;
                    case 2:
                        return ((FalseLiteral) curr.f0.choice).f0.tokenImage;
                    case 3:
                        theusevariables.add(((Identifier) curr.f0.choice).f0.tokenImage);
                        return ((Identifier) curr.f0.choice).f0.tokenImage;
                    case 4:
                        return ((ThisExpression) curr.f0.choice).f0.tokenImage;
                    case 5:
                        theusevariables.add(((ArrayAllocationExpression) curr.f0.choice).f3.f0.tokenImage);
                        return "new int [" + ((ArrayAllocationExpression) curr.f0.choice).f3.f0.tokenImage + "]";
                    case 6:
                        return "new " + ((AllocationExpression) curr.f0.choice).f1.f0.tokenImage + "()";
                    case 7: {
                        return "new " + ((NotExpression) curr.f0.choice).f1.f0.tokenImage + "()";
                    }
                }
                break;
            }
        }
        return  "";
    }

    public static String getTypeString(Type t) {
        switch (t.f0.which) {
            case 0:
                return "int []";
            case 1:
                return "boolean";
            case 2:
                return "int";
            case 3:
                return ((Identifier)t.f0.choice).f0.tokenImage;
        }
        return "";
    }

    public static void printBBToStreamAnalysisResult(BB startNode, StringBuilder sb, HashMap<Node, String> resultMap) {
        Set<BB> visitedBBs = new HashSet<>();
        Stack<BB> worklist = new Stack<>();

        worklist.push(startNode);

        while (worklist.size() > 0) {
            BB currentBB = worklist.pop();
            visitedBBs.add(currentBB);

            if (currentBB.outgoingEdges.size() > 0) {
                sb.append( "\n\"" + currentBB.name + "\" -> ");
                int i = 0;
                for (BB bbOut : currentBB.outgoingEdges) {
                    sb.append( "\"" + bbOut.name + "\"");
                    if (++i != currentBB.outgoingEdges.size()) {
                        sb.append(",");
                    }
                }
                sb.append(";\n");
            }
            if (currentBB.outgoingEdges.size() == 0) {
                sb.append("\n" + currentBB.name + " [style=\"rounded,filled\", shape=\"box\", fillcolor=\"orange\", fontname=\"monospace\", xlabel=\"End\", label=\"");
            } else if (currentBB.instructions.size() == 1) {
                sb.append("\n" + currentBB.name + " [fillcolor=\"gray\", style=\"filled\", shape=\"doublecircle\", fontname=\"monospace\", label=\"");
            } else if (currentBB.instructions.size() == 2 && currentBB.instructions.get(1).instructionNode instanceof Identifier) {
                sb.append("\n" + currentBB.name + " [fillcolor=\"gray\", style=\"rounded,filled\", shape=\"diamond\", fontname=\"monospace\", label=\"");
            } else {
                sb.append("\n" + currentBB.name + " [fillcolor=\"white\", style=\"filled\", shape=\"box\", fontname=\"monospace\", xlabel=\"" + currentBB.name + "\", label=\"");
            }

            for (Instruction i : currentBB.instructions) {
                if (i.instructionNode != null) {
                    Node instruction = i.instructionNode;
                    sb.append("[" + resultMap.get(instruction) + "]\n");
                }
            }

            sb.append("\"];");

            for (BB bbs : currentBB.outgoingEdges) {
                if (!visitedBBs.contains(bbs)) {
                    if (!worklist.contains(bbs)) {
                        worklist.push(bbs);
                    }
                }
            }

        }
    }

    public static void printBBToStream(BB startNode, StringBuilder sb, boolean dot) {
        Set<BB> visitedBBs = new HashSet<>();
        Stack<BB> worklist = new Stack<>();

        worklist.push(startNode);

        while (worklist.size() > 0) {
            BB currentBB = worklist.pop();
            visitedBBs.add(currentBB);

            if (currentBB.outgoingEdges.size() > 0) {
                sb.append( "\n\"" + currentBB.name + "\" -> ");
                int i = 0;
                for (BB bbOut : currentBB.outgoingEdges) {
                    sb.append( "\"" + bbOut.name + "\"");
                    if (++i != currentBB.outgoingEdges.size()) {
                        sb.append(",");
                    }
                }
                sb.append(";\n");
            }
            if (currentBB.outgoingEdges.size() == 0) {
                sb.append("\n" + currentBB.name + " [style=\"rounded,filled\", shape=\"box\", fillcolor=\"orange\", fontname=\"monospace\", xlabel=\"End\", label=\"");
            } else if (currentBB.instructions.size() == 1) {
                sb.append("\n" + currentBB.name + " [fillcolor=\"gray\", style=\"filled\", shape=\"doublecircle\", fontname=\"monospace\", label=\"");
            } else if (currentBB.instructions.size() == 2 && currentBB.instructions.get(1).instructionNode instanceof Identifier) {
                sb.append("\n" + currentBB.name + " [fillcolor=\"gray\", style=\"rounded,filled\", shape=\"diamond\", fontname=\"monospace\", label=\"");
            } else {
                sb.append("\n" + currentBB.name + " [fillcolor=\"white\", style=\"filled\", shape=\"box\", fontname=\"monospace\", xlabel=\"" + currentBB.name + "\", label=\"");
            }

            for (Instruction i : currentBB.instructions) {
                if (i.instructionNode != null) {
                    Node instruction = i.instructionNode;
                    if (instruction instanceof VarDeclaration) {
                        VarDeclaration curr = (VarDeclaration) instruction;
                        sb.append(getTypeString(curr.f0) + " " + curr.f1.f0.tokenImage + ";\n");
                    } else if (instruction instanceof AssignmentStatement) {
                        AssignmentStatement curr = (AssignmentStatement) instruction;
                        String lSide = curr.f0.f0.tokenImage;
                        String rSide = getExpressionString(curr.f2);
                        sb.append(lSide + " = " + rSide + ";\n");

                    } else if (instruction instanceof MethodDeclaration) {
                        MethodDeclaration node = (MethodDeclaration) i.instructionNode;
                        sb.append("return " + node.f10.f0.tokenImage + ";\n");
                    } else if (instruction instanceof PrintStatement) {
                        PrintStatement node = (PrintStatement) i.instructionNode;
                        sb.append("System.out.println(" + node.f2.f0.tokenImage + ");\n");
                    } else if(i.instructionNode instanceof ArrayAssignmentStatement) {
                        ArrayAssignmentStatement node = (ArrayAssignmentStatement) i.instructionNode;
                        String lSide = node.f0.f0.tokenImage + "_" + node.f2.f0.tokenImage;
                        String offset = node.f2.f0.tokenImage;
                        String rSide = node.f5.f0.tokenImage;
                        sb.append(lSide + "[" + offset + "] = " + rSide + ";\n");
                    } else if(i.instructionNode instanceof FieldAssignmentStatement) {
                        FieldAssignmentStatement node = (FieldAssignmentStatement) i.instructionNode;
                        String lSide = node.f0.f0.tokenImage;
                        String field = node.f2.f0.tokenImage;
                        String rSide = node.f4.f0.tokenImage;
                        sb.append(lSide + "." + field + " = " + rSide + ";\n");
                    } else if (i.instructionNode instanceof IfthenStatement) {
                        sb.append(((IfthenStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else if (i.instructionNode instanceof IfthenElseStatement) {
                        sb.append(((IfthenElseStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else if (i.instructionNode instanceof WhileStatement) {
                        sb.append(((WhileStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else {
                        throw new Error("Unhandled instruction in Basic Block: " + i.instructionNode);
                    }

                }
            }

            sb.append("\"];");

            for (BB bbs : currentBB.outgoingEdges) {
                if (!visitedBBs.contains(bbs)) {
                    if (!worklist.contains(bbs)) {
                        worklist.push(bbs);
                    }
                }
            }

        }
    }

    // A basic block with no outgoing edges is the end BB
    public static BB getEndBB(BB start) {
        Set<BB> visitedBBs = new HashSet<>();
        Stack<BB> worklist = new Stack<>();

        worklist.push(start);

        while (worklist.size() > 0) {
            BB currentBB = worklist.pop();
            visitedBBs.add(currentBB);

            if (currentBB.outgoingEdges.size() == 0) return currentBB;

            for (BB bbs : currentBB.outgoingEdges) {
                if (!visitedBBs.contains(bbs)) {
                    if (!worklist.contains(bbs)) {
                        worklist.push(bbs);
                    }
                }
            }

        }
        return null;
    }

    public static void printBBDOT(ProgramCFG programCFG) {
        StringBuilder sbMain = new StringBuilder();
        String mName = programCFG.mainMethod;
        BB mBB = programCFG.methodBBSet.get(mName);
        sbMain.append("digraph {\n");
        sbMain.append("rankdir=TB");
        printBBToStream(mBB, sbMain, true);
        sbMain.append("\n}");
        try {
            FileWriter myWriter = new FileWriter(mName + ".DOT");
            myWriter.write(sbMain.toString());
            myWriter.close();
        } catch (Exception e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        for (String className : programCFG.classMethodList.keySet()) {
            Set<String> methodList = programCFG.classMethodList.get(className);
            StringBuilder sb = new StringBuilder();
            for (String methodName : methodList) {
                BB currentMethodBB = programCFG.methodBBSet.get(methodName);
                sb.append("digraph {\n");
                sb.append("rankdir=TB");
                printBBToStream(currentMethodBB, sb, true);
                sb.append("\n}");
                try {
                    FileWriter myWriter = new FileWriter(methodName + ".DOT");
                    myWriter.write(sb.toString());
                    myWriter.close();
                } catch (Exception e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }
        }
    }

    // nithya
    public static Map<String, List<String>>ClassMethod_NodeOrder=new HashMap<>();
    public static Map<String, List<BB>>ClassMethod_NodeOrderBB=new HashMap<>();
    public static Map<String,Set<String>> ClassMethodVariablesList=new HashMap<>();
    public static Map<String, List<String>> NodePredecessor = new HashMap<>();
    public static Map<String,List<String>>IN=new HashMap<>();
    public static Map<String,List<String>>OUT=new HashMap<>();
    public static Map<String,Set<String>>USE=new HashMap<>();
    public static Map<String,Set<String>>DEF=new HashMap<>();

    public static Map<String,List<List<String>>>liveOUT=new HashMap<>();

    // private static Set<String> extractVariables(String expression) {
    //     Set<String> variables = new HashSet<>();
    //     String[] tokens = expression.split("[^a-zA-Z0-9_]"); 
    //     for (String token : tokens) {
    //         if (!token.isEmpty() && Character.isLetter(token.charAt(0))) { 
    //             if(!token.equals("true") && !token.equals("false") ){
    //                 variables.add(token);
    //             }
    //         }
    //     }
        
    //     return variables;
    // }
    
    public static void clearspecial(String Class_Method){
        for (BB everynodeBB : ClassMethod_NodeOrderBB.get(Class_Method)) {
            String everynode=everynodeBB.name;
            for (int i = 0; i < IN.get(everynode).size(); i++) {
                IN.get(everynode).set(i, "T");
            }
            for (int i = 0; i < OUT.get(everynode).size(); i++) {
                OUT.get(everynode).set(i,"T");
            }
        }
        // System.out.println("special cleaned");
    }
    public static int getNodeVarIndex(String var, String Class_Method) {
        Set<String> VariablesList = ClassMethodVariablesList.get(Class_Method);
        List<String> varList = new ArrayList<>(VariablesList);
        return varList.indexOf(var); 
    }

    // 1. INITIALISATION
    public static void initialise(List<String>SpeialInitilaisation, BB startNode, String Class_Method){
        // System.out.println("INIIII");
        Set<String> VariablesList = ClassMethodVariablesList.get(Class_Method);
        // System.out.println("$$$$$$$$$$$$$$$$"+Class_Method+" VariablesList: "+VariablesList);
        // System.out.println(SpeialInitilaisation);
        int n = VariablesList.size();

        if(SpeialInitilaisation.size()!=0){
            Map<String, String> mapping = new HashMap<>();
            for (String var : SpeialInitilaisation) {
                String[] parts = var.split("\\.");
                if (parts.length < 2) continue; 
                String number = parts[1].split(" ")[0]; 
                String[] subParts = parts[0].split("_");
                String key = subParts[subParts.length - 1]; // Get the last substring after "_"
                mapping.put(key, number);
            }
            List<String> finalList = new ArrayList<>();
            for (String element : VariablesList) {
                finalList.add(mapping.getOrDefault(element, "T"));
            }
            // System.out.println("FFFInalll "+ finalList);  // Output: [1, 2, 3, T]
        
            List<String> nodes = ClassMethod_NodeOrder.get(Class_Method);
            if (nodes == null || nodes.isEmpty()) {
                System.out.println("No nodes found for method: " + Class_Method);
                return;
            }
            for (String node : nodes) {
                IN.put(node, new ArrayList<>(finalList));
                // System.out.println(node+" speciallin "+IN.get(node));
            }
            for (String node : nodes) {
                OUT.put(node, new ArrayList<>(finalList));
                // System.out.println(node+" speciallout "+OUT.get(node));
            }
            for (BB everynodeBB : ClassMethod_NodeOrderBB.get(Class_Method)) {
                String everynode=everynodeBB.name;
                liveOUT.putIfAbsent(everynode, new ArrayList<>());
                for (Instruction i : everynodeBB.instructions) {
                    if (i.instructionNode != null) {
                        Node instruction = i.instructionNode;
                        if (instruction instanceof AssignmentStatement) {
                            liveOUT.get(everynode).add(new ArrayList<>(finalList));
                        }
                    }
                }

            }
            //    System.out.println(" block live ");

            // for (Map.Entry<String, List<List<String>>> entry : liveOUT.entrySet()) {
            //     System.out.println(entry.getKey() + " -> ");
            //     for (List<String> sublist : entry.getValue()) {
            //         System.out.println("  " + sublist); // Indented for readability
            //     }
            // }
            

        }
        else{
            List<String> nodes = ClassMethod_NodeOrder.get(Class_Method);
            if (nodes == null || nodes.isEmpty()) {
                System.out.println("No nodes found for method: " + Class_Method);
                return;
            }
            for (String node : nodes) {
                IN.put(node, new ArrayList<>(Collections.nCopies(n, "T")));
                // System.out.println(node+" plainIN "+IN.get(node));
            }
            for (String node : nodes) {
                OUT.put(node, new ArrayList<>(Collections.nCopies(n, "T")));
                // System.out.println(node+" plainout "+OUT.get(node));
            }
            // new nithya
            for (BB everynodeBB : ClassMethod_NodeOrderBB.get(Class_Method)) {
                String everynode=everynodeBB.name;
                liveOUT.putIfAbsent(everynode, new ArrayList<>());
                for (Instruction i : everynodeBB.instructions) {
                    if (i.instructionNode != null) {
                        Node instruction = i.instructionNode;
                        if (instruction instanceof AssignmentStatement) {
                            liveOUT.get(everynode).add(new ArrayList<>(Collections.nCopies(n, "T")));
                        }
                    }
                }

            }
            // System.out.println(" block live ");

            // for (Map.Entry<String, List<List<String>>> entry : liveOUT.entrySet()) {
            //     System.out.println(entry.getKey() + " -> ");
            //     for (List<String> sublist : entry.getValue()) {
            //         System.out.println("  " + sublist); // Indented for readability
            //     }
            // }

        }
    }
    
    

    public static void proceed( BB startNode, String Class_Method){
        // CLARITY!!!!
        // System.out.println("start prooooocedd");
        
        boolean same=false;
        Map<String,List<String>>INold=new HashMap<>();
        Map<String,List<String>>OUTold=new HashMap<>();
        for (Map.Entry<String, List<String>> entry : IN.entrySet()) {
            INold.put(entry.getKey(), new ArrayList<>(entry.getValue())); 
        }
        for (Map.Entry<String, List<String>> entry : OUT.entrySet()) {
            OUTold.put(entry.getKey(), new ArrayList<>(entry.getValue())); 
        }
        Set<String> VariablesList = ClassMethodVariablesList.get(Class_Method);
        
        // for every node
        while(!same){
            same=true;
            for (BB everynodeBB : ClassMethod_NodeOrderBB.get(Class_Method)) {
                // saving older values of IN and OUT
                String everynode=everynodeBB.name;

                for (int i = 0; i < IN.get(everynode).size(); i++) {
                    INold.get(everynode).set(i, IN.get(everynode).get(i));
                }
                for (int i = 0; i < OUT.get(everynode).size(); i++) {
                    OUTold.get(everynode).set(i, OUT.get(everynode).get(i));
                }

                // System.out.println("IN  " + everynode + ": " + IN.get(everynode));
                // System.out.println("INold " + everynode + ": " + INold.get(everynode));
                // System.out.println("OUT  " + everynode + ": " + OUT.get(everynode));
                // System.out.println("OUTold " + everynode + ": " + OUTold.get(everynode));


                List<String> everynodepred = NodePredecessor.get(everynode);
                if (everynodepred == null) everynodepred = new ArrayList<>(); 
                // System.out.println("PPPPPPPPPPPPP"+everynodepred);
                if(everynodepred.size()==0){
                    for (int i = 0; i < INold.get(everynode).size(); i++) {
                        IN.get(everynode).set(i, INold.get(everynode).get(i));
                    }
                }
                else{
                    int psize=everynodepred.size();
                    int size = VariablesList.size(); 
                    String prevblock=everynodepred.get(0);
                   
                    for (int i = 0; i < INold.get(everynode).size(); i++) {
                        IN.get(everynode).set(i, INold.get(everynode).get(i));
                    }
                    List<String> f=INold.get(everynode);
                    for (int index = 0; index < psize; index++) {
                        
                        String prevblock1=everynodepred.get(index);
                        List<String> p=OUT.get(prevblock1);
                        // System.out.println("!!!"+f);
                        // System.out.println("!!! "+index+" "+p);
                        for (int index2 = 0; index2 < size; index2++) {
                            if(f.get(index2).equals("B")){
                                IN.get(everynode).set(index2,"B");
                            }
                            else if(f.get(index2).equals("T")){
                                if(p.get(index2).equals("T")){
                                    IN.get(everynode).set(index2,"T");
                                }
                                else if(p.get(index2).equals("B")){
                                    IN.get(everynode).set(index2,"B");
                                }
                                else{
                                    IN.get(everynode).set(index2,p.get(index2));
                                }
                            }
                            else{
                                if(p.get(index2).equals("T")){
                                    IN.get(everynode).set(index2,f.get(index2));
                                }
                                else if(p.get(index2).equals("B")){
                                    IN.get(everynode).set(index2,"B");
                                }
                                else{
                                    if(p.get(index2).equals(f.get(index2))){
                                        IN.get(everynode).set(index2, p.get(index2));
                                    }
                                    else{
                                        IN.get(everynode).set(index2,"B");

                                    }
                                }
                            }
                        }
                        f=IN.get(everynode);
                        
                    }
                }

                // System.out.println("IN--   "+everynode+":"+IN.get(everynode));
                for (int i = 0; i < IN.get(everynode).size(); i++) {
                    OUT.get(everynode).set(i, IN.get(everynode).get(i));
                }

            
                // System.out.println("OUTB "+ everynode+": "+ OUT.get(everynode));
                int inst_num=-1;

                for (Instruction i : everynodeBB.instructions) {
                    if (i.instructionNode != null) {
                        Node instruction = i.instructionNode;
                        if (instruction instanceof AssignmentStatement) {
                            inst_num=inst_num+1;
                            AssignmentStatement curr = (AssignmentStatement) instruction;
                            String lSide = curr.f0.f0.tokenImage;
                            String rSide = getExpressionString(curr.f2);
                            // System.out.println("        "+lSide+" = "+rSide+"+++++++++++++");

                            int ind_v = getNodeVarIndex(lSide, Class_Method); 

                            rSide= rSide.trim(); 
                            if (inst_num > 0) {
                                List<String> prevstliv = liveOUT.get(everynode).get(inst_num - 1);
                                liveOUT.get(everynode).set(inst_num, new ArrayList<>(prevstliv)); // Replace index `inst_num`
                            }

                            if (rSide.matches("-?\\d+")){

                                OUT.get(everynode).set(ind_v, rSide);
                                liveOUT.get(everynode).get(inst_num).set(ind_v,rSide);
                            }
                            else if (rSide.contains("+")) {
                                String[] parts = rSide.split("\\+"); 
                                String a = parts[0].trim();
                                String b = parts[1].trim();
                                int ind_w1 = getNodeVarIndex(a, Class_Method);
                                int ind_w2 = getNodeVarIndex(b, Class_Method);
                                // System.out.println(everynode+" BBX^^");

                                String val1 = OUT.get(everynode).get(ind_w1);
                                String val2 = OUT.get(everynode).get(ind_w2);
                                
                                if(val1.equals("B") || val2.equals("B")){
                                // System.out.println(val1+" "+val2+" ^^^^^B  B^^");
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                    OUT.get(everynode).set(ind_v, "B");
                                }
                                else if(val1.equals("T") || val2.equals("T")){
                                // System.out.println(val1+" "+val2+" ^^^^^T T^^^^");

                                liveOUT.get(everynode).get(inst_num).set(ind_v,"T");
                                    OUT.get(everynode).set(ind_v, "T");
                                }
                                else{
                                // System.out.println(val1+" "+val2+" ^^^^^^^^^^^^^^^");

                                    int ans=Integer.parseInt(val1)+Integer.parseInt(val2);
                                liveOUT.get(everynode).get(inst_num).set(ind_v,ans+"");
                                    OUT.get(everynode).set(ind_v, ans+"");

                                }
                            }
                            else if (rSide.contains("-")) {
                                String[] parts = rSide.split("\\-"); 
                                String a = parts[0].trim();
                                String b = parts[1].trim();
                                int ind_w1 = getNodeVarIndex(a, Class_Method);
                                int ind_w2 = getNodeVarIndex(b, Class_Method);
                                String val1 = OUT.get(everynode).get(ind_w1);
                                String val2 = OUT.get(everynode).get(ind_w2);
                                if(val1=="B" || val2=="B"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                    OUT.get(everynode).set(ind_v, "B");
                                }
                                else if(val1=="T" || val2=="T"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"T");
                                    OUT.get(everynode).set(ind_v, "T");
                                }
                                else{
                                    int ans=Integer.parseInt(val1)-Integer.parseInt(val2);
                                liveOUT.get(everynode).get(inst_num).set(ind_v,ans+"");
                                    OUT.get(everynode).set(ind_v, ans+"");

                                }
                            } 
                            else if (rSide.contains("*")) {
                                String[] parts = rSide.split("\\*"); 
                                String a = parts[0].trim();
                                String b = parts[1].trim();
                                int ind_w1 = getNodeVarIndex(a, Class_Method);
                                int ind_w2 = getNodeVarIndex(b, Class_Method);
                                String val1 = OUT.get(everynode).get(ind_w1);
                                String val2 = OUT.get(everynode).get(ind_w2);
                                if(val1=="B" || val2=="B"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                    OUT.get(everynode).set(ind_v, "B");
                                }
                                else if(val1=="T" || val2=="T"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"T");
                                    OUT.get(everynode).set(ind_v, "T");
                                }
                                else{
                                    int ans=Integer.parseInt(val1)*Integer.parseInt(val2);
                                liveOUT.get(everynode).get(inst_num).set(ind_v,ans+"");
                                    OUT.get(everynode).set(ind_v, ans+"");

                                }
                            }
                            else if (rSide.contains("/")) {
                                String[] parts = rSide.split("\\/"); 
                                String a = parts[0].trim();
                                String b = parts[1].trim();
                                int ind_w1 = getNodeVarIndex(a, Class_Method);
                                int ind_w2 = getNodeVarIndex(b, Class_Method);
                                String val1 = OUT.get(everynode).get(ind_w1);
                                String val2 = OUT.get(everynode).get(ind_w2);
                                if(val1=="B" || val2=="B"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                    OUT.get(everynode).set(ind_v, "B");
                                }
                                else if(val1=="T" || val2=="T"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"T");
                                    OUT.get(everynode).set(ind_v, "T");
                                }
                                else{
                                    int ans=Integer.parseInt(val1)/Integer.parseInt(val2);
                                liveOUT.get(everynode).get(inst_num).set(ind_v,ans+"");
                                    OUT.get(everynode).set(ind_v, ans+"");

                                }
                            }
                            
                            else{

                                if(rSide.equals("true") || rSide.equals("false")){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                    OUT.get(everynode).set(ind_v, "B");
                                }
                                else{
                                    int ind_w = getNodeVarIndex(rSide, Class_Method);

                                // System.out.println(rSide+" ^^^^^^^^^^^^^^^  "+ind_w);HELLLLPPPP

                                    if(ind_w==-1){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                        OUT.get(everynode).set(ind_v, "B");
                                    }
                                    else{
                                        String val = OUT.get(everynode).get(ind_w);

                                        if(val=="B"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"B");
                                            OUT.get(everynode).set(ind_v, "B");
                                        }
                                        else if(val=="T"){
                                liveOUT.get(everynode).get(inst_num).set(ind_v,"T");
                                            OUT.get(everynode).set(ind_v, "T");
                                        }
                                        else{
                                            int ans=Integer.parseInt(val);
                                liveOUT.get(everynode).get(inst_num).set(ind_v,ans+"");
                                            OUT.get(everynode).set(ind_v, ans+"");
                                        }
                                    }
                                    
                                }
                                
                            }

                            // // print complex
                            // System.out.println("AFTER: " + everynode+"-"+inst_num+": "); 
                            // for (List<String> sublist : liveOUT.get(everynode)) {
                            //     System.out.println("    liveout: " + sublist); 
                            // }
                        }
                    }
                }
                // System.out.println("OUT: "+ everynode+": "+ OUT.get(everynode));
                


                if(!INold.get(everynode).equals(IN.get(everynode)) || !OUTold.get(everynode).equals(OUT.get(everynode))){
                    same=false;
                }
            }
        }
        
    }
public static Set<String> theusevariables=new HashSet<>();
    public static void nodetravelorder(BB startNode, String Class_Method){
        // System.out.print("VAYYYYARI");
        //  travel nodes in the order; ClassMethod_NodeOrder:      TestTC01.TestTC01_foo -> [bb1, bb2, bb3, bb5, bb6, bb4
        if (!ClassMethod_NodeOrder.containsKey(Class_Method)) {
            ClassMethod_NodeOrder.put(Class_Method, new ArrayList<>());
        }
        if (!ClassMethod_NodeOrderBB.containsKey(Class_Method)) {
            ClassMethod_NodeOrderBB.put(Class_Method, new ArrayList<>());
        }
        Stack<BB> worklist = new Stack<>();
        Set<BB> visited = new HashSet<>();

        worklist.push(startNode);
        visited.add(startNode);

        while (!worklist.isEmpty()) {
            BB currentBB = worklist.pop();
            ClassMethod_NodeOrder
            .computeIfAbsent(Class_Method, k -> new ArrayList<>())
            .add(currentBB.name);
            ClassMethod_NodeOrderBB
            .computeIfAbsent(Class_Method, k -> new ArrayList<>())
            .add(currentBB);
            List<BB> outgoing = new ArrayList<>(currentBB.outgoingEdges);
            Collections.reverse(outgoing);
            for (BB neighbor : outgoing) {
                if (!visited.contains(neighbor)) {
                    worklist.push(neighbor);
                    visited.add(neighbor);
                }
            }
        }
        worklist.clear();
        visited.clear();
        
        // print NODE ORDER
        // if (ClassMethod_NodeOrder.containsKey(Class_Method)) {
        //     System.out.print("CCCCCCCCCCCC "+Class_Method + " -> ");
        //     System.out.println(ClassMethod_NodeOrder.get(Class_Method)); 
        // } else {
        //     System.out.println("Class method not found: " + Class_Method);
        // }

        // Initialisation NodeVariables, OUT
        worklist.push(startNode);

        while (worklist.size() > 0) {
            BB currentBB = worklist.pop();
            visited.add(currentBB);
            for (BB bbIncoming : currentBB.incomingEdges) {
                NodePredecessor.computeIfAbsent(currentBB.name, k->new ArrayList<>())
                .add(bbIncoming.name);
            }
            StringBuilder sb = new StringBuilder();
            for (Instruction i : currentBB.instructions) {
                if (i.instructionNode != null) {
                    Node instruction = i.instructionNode;
                    if (instruction instanceof VarDeclaration) {
                        VarDeclaration curr = (VarDeclaration) instruction;
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>())
                        .add(curr.f1.f0.tokenImage);
                        sb.append(getTypeString(curr.f0) + " " + curr.f1.f0.tokenImage + ";\n");
                    } else if (instruction instanceof AssignmentStatement) {
                        AssignmentStatement curr = (AssignmentStatement) instruction;
                        String lSide = curr.f0.f0.tokenImage;
                        theusevariables=new HashSet<>();
                        String rSide = getExpressionString(curr.f2);
                        sb.append(lSide + " = " + rSide + ";\n");
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>())
                        .add(lSide);
                        for(String gg:theusevariables){
                            ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>())
                            .add(gg);
                        }
                        DEF.computeIfAbsent(currentBB.name, k -> new HashSet<>())
                        .add(lSide);
                        for(String gg:theusevariables){
                            USE.computeIfAbsent(currentBB.name, k-> new HashSet<>())
                            .add(gg);
                        }

                    } else if (instruction instanceof MethodDeclaration) {
                        MethodDeclaration node = (MethodDeclaration) i.instructionNode;
                        USE.computeIfAbsent(currentBB.name, k -> new HashSet<>())
                        .add(node.f10.f0.tokenImage);
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>()).add(node.f10.f0.tokenImage);
                        sb.append("return " + node.f10.f0.tokenImage + ";\n");
                    } else if (instruction instanceof PrintStatement) {
                        PrintStatement node = (PrintStatement) i.instructionNode;
                        USE.computeIfAbsent(currentBB.name, k -> new HashSet<>())
                        .add(node.f2.f0.tokenImage);
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>()).add(node.f2.f0.tokenImage);
                    } else if(i.instructionNode instanceof ArrayAssignmentStatement) {
                        ArrayAssignmentStatement node = (ArrayAssignmentStatement) i.instructionNode;
                        String lSide = node.f0.f0.tokenImage + "_" + node.f2.f0.tokenImage;
                        String offset = node.f2.f0.tokenImage;
                        String rSide = node.f5.f0.tokenImage;
                        sb.append(lSide + "[" + offset + "] = " + rSide + ";\n");
                        USE.computeIfAbsent(currentBB.name, k -> new HashSet<>())
                        .add(offset);
                        USE.computeIfAbsent(currentBB.name, k -> new HashSet<>())
                        .add(rSide);
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>()).add(offset);
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>()).add(rSide);

                    } else if(i.instructionNode instanceof FieldAssignmentStatement) {
                        FieldAssignmentStatement node = (FieldAssignmentStatement) i.instructionNode;
                        String lSide = node.f0.f0.tokenImage;
                        String field = node.f2.f0.tokenImage;
                        String rSide = node.f4.f0.tokenImage;
                        sb.append(lSide + "." + field + " = " + rSide + ";\n");
                        USE.computeIfAbsent(currentBB.name, k -> new HashSet<>())
                        .add(rSide);
                        ClassMethodVariablesList.computeIfAbsent(Class_Method, k-> new HashSet<>()).add(rSide);

                    } else if (i.instructionNode instanceof IfthenStatement) {
                        sb.append(((IfthenStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else if (i.instructionNode instanceof IfthenElseStatement) {
                        sb.append(((IfthenElseStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else if (i.instructionNode instanceof WhileStatement) {
                        sb.append(((WhileStatement)i.instructionNode).f2.f0.tokenImage + "\n");
                    } else {
                        throw new Error("Unhandled instruction in Basic Block: " + i.instructionNode);
                    }
                }
            }
            for (BB bbs : currentBB.outgoingEdges) {
                if (!visited.contains(bbs)) {
                    if (!worklist.contains(bbs)) {
                        worklist.push(bbs);
                    }
                }
            }
        }
    }
}
