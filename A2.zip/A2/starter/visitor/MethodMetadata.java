package visitor;

public class MethodMetadata {
}
