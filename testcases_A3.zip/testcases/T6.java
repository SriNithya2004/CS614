/*4*/
class T6 {
    public static void main(String[] args) {
        TestT6 o;
        int res;
        o = new TestT6();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT6 {
    public int foo() {
        int sum;
        int a;
        int b;
        boolean c;
        int d;
        int i;
        int j;
        boolean k;
        boolean l;
        a = 10;
        b = 5;
        d = 1;
        sum = 0;
        i = 0;
        j = 100;
        k = i <= a;
        l = j <= b;
        while(k) {
        	j = 0;
            while (l) {
            	d = i / b;
                if (l) {
                    sum = i * j;
                }else {
                    sum = i * j;
                }
                j = j + d;
                l = j <= b;
            }
            i = i + d;
            k = i <= a;
        }
        return sum;
    }
}
