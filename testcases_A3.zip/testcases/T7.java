/*5*/
class T7 {
    public static void main(String[] args) {
        TestT7 o;
        int res;
        o = new TestT7();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT7 {
    public int foo() {
        int a;
        int b;
        boolean c;
        boolean d;
        boolean e;
        int f;
        boolean g;
        boolean h;
        int i;
        int j;
        int k;
        boolean l;
        int sum;
        a = 10;
        b = 5;
        d = true;
        e = false;
        i = 0;
        j = 0;
        k = 1;
        f = 375;
        g = i <= a;
        l = j <= b;
        if (g) {
            h = d && e;
        }else {
            h = d || e;
        }
        while (l) {
        	i = i / b;
            if (h) {
                f = a * b;
                f = f * a;
			}
            j = j + k;
            l = j <= b;
        }
        return f;
    }
}
