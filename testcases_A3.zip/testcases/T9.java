/*3*/
class T9 {
    public static void main(String[] args) {
        TestT9 o;
        int res;
        o = new TestT9();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT9 {
    public int foo() {
        int sum;
        int a;
        int b;
        boolean c;
        int d;
        int i;
        boolean k;
        a = 10;
        b = 5;
        d = 1;
        sum = 60;
        i = 0;
    	c = i <= b;
        if (c) {
            k = i <= a;
    		while(k) {
            	sum = i * a;
            	i = i + d;
            	k = i <= a;
            }
        }else {
        	k = i <= a;
    		while(k) {
    			sum = i * a;
            	i = i + d;
            	k = i <= a;
            }
        }
        return sum;
    }
}
