/*4*/
class T8 {
    public static void main(String[] args) {
        TestT8 o;
        int res;
        o = new TestT8();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT8 {
    public int foo() {
        int sum;
        int a;
        int b;
        boolean c;
        int d;
        int i;
        boolean k;
        int t;
        int u;
        int v;
        int w;
        int x;
        int y;
        int z;
        a = 10;
        b = 5;
        d = 1;
        i = 0;
        k = i <= a;
        u = 10;
        v = 20;
        w = 30;
        x = 40;
        z = 100;
        while(k) {
        	c = i <= b;
            if (c) {
                sum = i * a;
            }else {
                sum = i * b;
            }
            y = u * v;
            t = sum + x;
            w = w + t;
            y = y / z;
            z = z - y;
            i = i + d;
            k = i <= a;
        }
        return u;
    }
}
