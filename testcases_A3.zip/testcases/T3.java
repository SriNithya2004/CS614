/*7*/
class T3 {
    public static void main(String[] args) {
        TestT3 o;
        int res;
        o = new TestT3();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT3 {
    public int foo() {
        int a;
        int b;
        int c;
        int d;
        int e;
        int f;
        int g;
        int h;
        int i;
        a = 5;
        b = 1;
        c = 7;
        d = 8;
        e = 9;
        g = 11;
        h = 12;
        i = g + c;
        f = i + h;
        g = f * e;
        c = d * g;
        d = c - b;
        a = a * d;
        return a;
    }
}
