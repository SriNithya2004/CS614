/*2*/
class T2 {
    public static void main(String[] args) {
        TestT2 o;
        int res;
        o = new TestT2();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT2 {
    public int foo() {
        int a;
        int b;
        int c;
        int d;
        int e;
        int t;
        a = 5;
        b = 6;
        c = a + b;
        d = c + a;
        e = a - c;
        t = d - e;
        return t;
    }
}
