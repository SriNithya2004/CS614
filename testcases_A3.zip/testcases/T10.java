/*2*/
class T10 {
    public static void main(String[] args) {
        TestT10 o;
        int res;
        o = new TestT10();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT10 {
    public int foo() {
        int a;
        boolean b;
        int c;
        int e;
        int g;
        int h;
        int i;
        c = 0;
        a = 64;
        i = 49;
        b = a <= c;
        if (b) {
            h = 1;
            a = 71;
            g = a - h;
            e = g * i;
            a = e;
        } else {
            e = 1;
            a = e;
        }
        return a;
    }
}
