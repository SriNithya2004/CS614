/*4*/
class T5 {
    public static void main(String[] args) {
        TestT5 o;
        int res;
        o = new TestT5();
        res = o.foo();
        System.out.println(res);
    }
}
class TestT5 {
    public int foo() {
        int sum;
        int a;
        int b;
        boolean c;
        int d;
        int i;
        boolean k;
        a = 10;
        b = 5;
        d = 1;
        sum = 10;
        i = 0;
        k = i <= a;
        while(k) {
        	c = i <= b;
            if (c) {
                sum = i * a;
            }else {
                sum = i * b;
            }
            
            i = i + d;
			k = i <= a;
        }
        return sum;
    }
}
