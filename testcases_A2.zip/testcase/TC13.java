class TC13 {
    public static void main(String[] args) {
        TestTC13 o;
        int res;
        o = new TestTC13();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC13 {
    public int foo() {
        int x;
        int y;
        int z;
        Test2TC13 obj1;
        Test2TC13 obj2;
        Test2TC13 obj3;
        int a;
        int b;
        int c;
        x = 7;
        y = 3;
        a = x + y;
        obj1 = new Test2TC13();
        obj2 = new Test2TC13();
        obj3 = new Test2TC13();
        z = obj1.bar(a);
        b = obj2.foobar(a);
        c = obj3.bar(a);
        return z;
    }
}
class Test2TC13  extends TestTC13 {
    public int bar(int p1) {
        int x;
        int y;
        int z;
        int a;
        x = 7;
        y = 3;
        a = x + y;
        z = a + p1;
        return p1;
    }
    public int foobar(int p1) {
        int x;
        int y;
        int a;
        x = 7;
        y = 3;
        a = x + y;
        p1 = a + p1;
        return a;
    }
}