class TC09 {
    public static void main(String[] args) {
        TestTC09 o;
        int res;
        o = new TestTC09();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC09 {
    public int foo() {
        int w;
        int x;
        int y;
        boolean z;
        int a;
        x = 7;
        y = 3;
        w = 10;
        z = w <= x;
        a = 3;
        if(z) {
            while(z) {
                w = w - y;
                x = x + y;
                z = x <= w;
                a = y;
            }
        } else {
            while (z) {
                w = w + y;
                x = x - y;
                a = y;
            }
        }
        a = a + y;
        return a;
    }
}