class TC07 {
    public static void main(String[] args) {
        TestTC07 o;
        int res;
        o = new TestTC07();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC07 {
    public int foo() {
        int x;
        int y;
        boolean z;
        int i;
        int sum;
        z = true;
        x = 7;
        y = 3;
        i = 1;
        sum = 0;
        if (z) {
            x = x + y;
        }
        z = x <= i;
        while (z) { 
            sum = sum + i;
            i = i + i;
        }
        return sum;
    }
}