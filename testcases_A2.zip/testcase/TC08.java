class TC08 {
    public static void main(String[] args) {
        TestTC08 o;
        int res;
        o = new TestTC08();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC08 {
    int f1;
    int f2;
    boolean f3;
    public int foo() {
        int w;
        int w2;
        int x;
        int y;
        boolean z;
        int a;
        TestTC08 obj;
        z = true;
        x = 7;
        y = 3;
        w = 10;
        obj = new TestTC08();
        obj.f2 = x;
        f2 = 30;
        a = f2;
        if (z) {
            w = x + y;
            obj.f1 = x;
            w2 = x + y;
            obj.f2 = w2;
        }
        z = x <= w;
        if(z) {
           x = w - y;  
        }
        return x;
    }
}