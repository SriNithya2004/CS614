class TC12 {
    public static void main(String[] args) {
        TestTC12 o;
        int res;
        o = new TestTC12();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC12 {
    public int foo() {
        int x;
        int y;
        int z;
        Test2TC12 obj1;
        int a;
        x = 7;
        y = 3;
        a = x + y;
        obj1 = new Test2TC12();
        z = obj1.bar(a);
        return z;
    }
}
class Test2TC12  extends TestTC12 {
    public int bar(int p1) {
        int x;
        int y;
        int z;
        int a;
        x = 7;
        y = 3;
        a = x + y;
        z = a + p1;
        return p1;
    }
}