class TC11 {
    public static void main(String[] args) {
        TestTC11 o;
        int res;
        o = new TestTC11();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC11 {
    public int foo() {
        int x;
        int y;
        int z;
        Test2TC11 obj1;
        int a;
        x = 7;
        y = 3;
        a = x + y;
        obj1 = new Test2TC11();
        z = obj1.bar();
        return z;
    }
}
class Test2TC11  extends TestTC11 {
    public int bar() {
        int x;
        int y;
        int a;
        x = 7;
        y = 3;
        a = x + y;
        return a;
    }
}