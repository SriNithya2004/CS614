class TC05 {
    public static void main(String[] args) {
        TestTC05 o;
        int res;
        o = new TestTC05();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC05 {
    public int foo() {
        int a;
        int x;
        int y;
        int z;
        int result;
        int result2;
        boolean cond;
        a = 2;
        x = 10;
        y = 20;
        z = 30;
        cond = true; 
        if (cond) {
            result = x * a; // 10 * 2 = 20
            result2 = result / y; // 20 / 20 = 1
        } else {
            result = z - y; // 30 - 20 = 10
            result2 = result / x; // 10 / 10 = 1
        }
        return result; 
    }
}
