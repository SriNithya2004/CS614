class TC06 {
    public static void main(String[] args) {
        TestTC06 o;
        int res;
        o = new TestTC06();
        res = o.foo();
        System.out.println(res);
    }
}

class TestTC06 {
    public int foo() {
        int a;
        int b;
        int c;
        int i;
        int j;
        boolean z;
        a = 2;
        b = 3;
        i = 0;
        j = 1;
        c = a * b; // 6
        z = b <= i;
        while(z) {
            c = c + a; // Should propagate c = 6 + 2 = 8
            i = i + j; // Should propagate i = 1
        }

        return c; // Should be 6 + 2 * 5 = 16
    }
}
