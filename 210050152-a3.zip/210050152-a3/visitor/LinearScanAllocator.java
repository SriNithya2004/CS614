package visitor;

import java.util.*;

public class LinearScanAllocator {
    private final HashMap<String, int[]> variableOccurrenceMap;
    private final int numRegisters;
    private final Map<String, String> allocation = new LinkedHashMap<>(); // register or spilled

    public LinearScanAllocator(HashMap<String, int[]> variableOccurrenceMap, int numRegisters) {
        this.variableOccurrenceMap = variableOccurrenceMap;
        this.numRegisters = numRegisters;
    }

    public Map<String, String> allocateRegisters() {

        //sort by start time
        List<Map.Entry<String, int[]>> sortedVariables = new ArrayList<>(variableOccurrenceMap.entrySet());
        sortedVariables.sort(Comparator
        .comparingInt((Map.Entry<String, int[]> e) -> e.getValue()[0]) 
        .thenComparing(Map.Entry::getKey)); 

        // for (Map.Entry<String, int[]> entry : sortedVariables) {
        //     System.out.print(entry.getKey() + " -> ");
        //     System.out.println(Arrays.toString(entry.getValue())); 
        // }
        

        // active list sorted by increasing end time
        List<Map.Entry<String, int[]>> active = new ArrayList<>();
        boolean[] allocatedRegisters = new boolean[numRegisters];
        int spillindex=0;

        for (Map.Entry<String, int[]> current : sortedVariables) {
            int start = current.getValue()[0];
            int end = current.getValue()[1];

            // active.removeIf(e -> e.getValue()[1] < start); // remove all expired variable
            Iterator<Map.Entry<String, int[]>> iterator = active.iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, int[]> entry = iterator.next();
                if (entry.getValue()[1] < start) { 
                    String reg = allocation.get(entry.getKey()); 
                    if (reg != null && reg.startsWith("R")) { 
                        int regIndex = Integer.parseInt(reg.substring(1)); 
                        allocatedRegisters[regIndex] = false; 
                    }
                    iterator.remove();
                }
            }


            if (active.size() < numRegisters) {
                String reg = null;
                for (int i = 0; i < allocatedRegisters.length; i++) {
                    if (!allocatedRegisters[i]) { 
                        allocatedRegisters[i] = true; 
                        reg = "R" + i; 
                        break;
                    }
                }
                allocation.put(current.getKey(), reg);
                active.add(current);
                active.sort(Comparator
                .comparingInt((Map.Entry<String, int[]> e) -> e.getValue()[1]) 
                .thenComparing(Map.Entry::getKey, Comparator.reverseOrder())); 

            } else {
               Map.Entry<String, int[]> spillCandidate;

                if(active.size()>=1){
                    spillCandidate = active.get(active.size() - 1);
                }
                else{
                    allocation.put(current.getKey(), "SPILLED"+spillindex);
                    spillindex=spillindex+1;  
                    continue;
                }
                if (spillCandidate.getValue()[1] > end) {
                    String theReg = allocation.get(spillCandidate.getKey()); 
                    allocation.put(spillCandidate.getKey(), "SPILLED"+spillindex);
                    spillindex=spillindex+1;
                    allocation.put(current.getKey(), theReg);
                    active.remove(spillCandidate);
                    active.add(current);
                    active.sort(Comparator
                    .comparingInt((Map.Entry<String, int[]> e) -> e.getValue()[1]) 
                    .thenComparing(Map.Entry::getKey, Comparator.reverseOrder())); 

                } 
                // else if (spillCandidate.getValue()[1] == end){
                //     if (current.getKey().compareTo(spillCandidate.getKey()) < 0) {
                //         allocation.put(current.getKey(), "SPILLED"+spillindex);
                //         spillindex=spillindex+1;        
                //     }
                //     else{
                //         String theReg = allocation.get(spillCandidate.getKey()); 
                //         allocation.put(spillCandidate.getKey(), "SPILLED"+spillindex);
                //         spillindex=spillindex+1;
                //         allocation.put(current.getKey(), theReg);
                //         active.remove(spillCandidate);
                //         active.add(current);
                //         active.sort(Comparator
                //         .comparingInt((Map.Entry<String, int[]> e) -> e.getValue()[1]) 
                //         .thenComparing(Map.Entry::getKey, Comparator.reverseOrder()));
                //     }
                // }
                 else {
                    allocation.put(current.getKey(), "SPILLED"+spillindex);
                    spillindex=spillindex+1;
                }
            }
            // for (Map.Entry<String, String> entry : allocation.entrySet()) {
            //     System.out.println(entry.getKey() + " --> " + entry.getValue());
            // }
            // System.out.println();

        }

        return allocation;
    }

    
}
