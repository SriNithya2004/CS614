import syntaxtree.*;
import visitor.*;
import java.util.*;
import java.io.*;

public class Main {

   public static HashMap<String, int[]> processLogFile(String fileName, int[] numRegisters) {
      HashMap<String, int[]> variable_liveness = new HashMap<>();

      try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
          String line;
          boolean firstLine = true;

          while ((line = reader.readLine()) != null) {
            // numRegisters[0]
              if (firstLine) {
                  numRegisters[0] = Integer.parseInt(line.trim());
                  firstLine = false;
                  continue;
              }

              String[] parts = line.split("\\]");
              if (parts.length < 2) continue;

              int statementId = Integer.parseInt(parts[0].replaceAll("[^0-9]", "").trim());

              String[] statementParts = parts[1].split(":");
              if (statementParts.length > 1) {
                  String variables = statementParts[1].trim().replaceAll("[\\[\\]]", "");

                  if (!variables.isEmpty()) {
                      for (String var : variables.split(",\\s*")) {
                          if (!variable_liveness.containsKey(var)) {
                              variable_liveness.put(var, new int[]{statementId, statementId});
                          } else {
                              variable_liveness.get(var)[1] = statementId;
                          }
                      }
                  }
              }
          }
        } catch (IOException e) {
            System.err.println("Error reading the log file: " + e.getMessage());
        }

      return variable_liveness;
  }

   public static void main(String [] args) {
      try {

         Node root = new A3Java(System.in).Goal();
         CFGGen cfgGen = new CFGGen();
         root.accept(cfgGen);

         ProgramCFG programCFG = cfgGen.getCFG();
         // BB.printBBDOT(programCFG);

         RunAnalysis ra = new RunAnalysis(programCFG);
         ra.startAnalysisBackward();

         // Result Map contains a mapping from statements to live variables at that statement
         HashMap<Node, Set<String>> resultMap = ra.getResultMap();



         PrintStream originalOut = System.out;
            try {
                PrintStream fileOut = new PrintStream(new File("log.txt"));
                System.setOut(fileOut);

               //  count registers
               root.accept(new RegisterCounter<Void, Void>(), null);

                // for (Map.Entry<String, Map<String, List<String>>> classEntry : RegisterCounter.Type_Variable.entrySet()) {
                //     System.out.println("Class: " + classEntry.getKey());
                //     for (Map.Entry<String, List<String>> methodEntry : classEntry.getValue().entrySet()) {
                //         System.out.println("  Method: " + methodEntry.getKey());
                //         System.out.println("    Variables: " + methodEntry.getValue());
                //     }
                // }

               // variable liveness
                ResultPrinter resultPrinter = new ResultPrinter(resultMap);
                root.accept(resultPrinter);
                fileOut.close();
            } catch (FileNotFoundException e) {
                System.err.println("Error: Unable to create or write to log.txt");
                e.printStackTrace();
            }
         System.setOut(originalOut);


         int[] numRegisters = {0};
         HashMap<String, int[]> variable_liveness=processLogFile("log.txt", numRegisters);

        //  System.out.println("::::::::::::"+numRegisters[0]);
        //  for (Map.Entry<String, int[]> entry : variable_liveness.entrySet()) {
        //      System.out.println(entry.getKey() + " -> [" + entry.getValue()[0] + ", " + entry.getValue()[1] + "]");
        //  }
         


         LinearScanAllocator allocator = new LinearScanAllocator(variable_liveness, numRegisters[0]);
         Map<String, String> registerinfo=allocator.allocateRegisters(); 
       
         // for (Map.Entry<String, String> entry : registerinfo.entrySet()) {
        //     System.out.println(entry.getKey() + " --> " + entry.getValue());
        // }

        root.accept(new travelnithya<Void, Void>(numRegisters[0], registerinfo, variable_liveness), null);
         // Assignment Starts here
         // You can write your own custom visitor(s)
         
      }
      catch (ParseException e) {
         System.out.println(e.toString());
      }
   }
}
